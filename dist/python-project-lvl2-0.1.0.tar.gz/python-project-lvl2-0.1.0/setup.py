# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['test_folder']

package_data = \
{'': ['*']}

install_requires = \
['flake8>=3.8.4,<4.0.0']

setup_kwargs = {
    'name': 'python-project-lvl2',
    'version': '0.1.0',
    'description': 'start',
    'long_description': None,
    'author': 'NeoVic2006',
    'author_email': 'NeoVic2006@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
